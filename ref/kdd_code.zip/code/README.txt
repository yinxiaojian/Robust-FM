matlab code for paper:
Huo, Zhouyuan, Feiping Nie, and Heng Huang. "Robust and Effective Metric Learning Using Capped Trace Norm." KDD 2016	


how to run this code:
1. run GenerateData to generate synthetic data.
2. run test_cap.
